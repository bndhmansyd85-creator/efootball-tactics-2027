eFootball Tactics 2027 - Android Project

هذا مشروع Android حقيقي يحتوي نسخة الويب داخل التطبيق عبر WebView.

للبناء:
1. افتح المجلد في Android Studio.
2. انتظر مزامنة Gradle.
3. Build > Build APK(s).
4. ستجد APK في app/build/outputs/apk/debug/

اسم الحزمة:
com.efootball.tactics2027

المشروع يطلب إذن إشعارات Android 13+، ويحتوي أخبار KONAMI وزر الإشعارات وبيانات المدربين التي يدخلها المستخدم.
